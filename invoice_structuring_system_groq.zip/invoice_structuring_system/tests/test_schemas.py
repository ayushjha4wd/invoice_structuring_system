import pytest
from pydantic import ValidationError
from src.schemas.invoice_schema import InvoiceData

def test_schema_accepts_known_fields():
    data = InvoiceData(
        seller={"name": "Seller"}, buyer={"name": "Buyer"},
        consignee={"name": "Consignee"}, invoice={"number": "INV-1"}
    )
    assert data.invoice.number == "INV-1"

def test_schema_rejects_unknown_fields():
    with pytest.raises(ValidationError):
        InvoiceData(seller={"name": "Seller", "unknown": "value"})
