import argparse, json
from src.pipelines.deterministic.extractor import DeterministicExtractor

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["deterministic", "llm", "both"], required=True)
    parser.add_argument("--input", required=True)
    args = parser.parse_args()
    if args.mode in {"deterministic", "both"}:
        print(json.dumps(DeterministicExtractor().extract(args.input).model_dump(), indent=2))
    if args.mode in {"llm", "both"}:
        from src.pipelines.llm.extractor import LLMExtractor
        print(json.dumps(LLMExtractor().extract(args.input).model_dump(), indent=2))

if __name__ == "__main__":
    main()
