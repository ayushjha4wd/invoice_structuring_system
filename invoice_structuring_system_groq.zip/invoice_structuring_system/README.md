# Invoice Structuring System

## Two solutions

### Solution 1 — Deterministic / Zero LLM
- PyMuPDF text extraction
- Tesseract OCR fallback
- Regex
- Label/alias matching
- Layout/coordinate analysis
- Table parsing
- Normalization
- Pydantic validation

There are **no LLM calls** in this pipeline.

### Solution 2 — Groq LLM
- Groq API
- Open-weight Qwen multimodal model
- Structured JSON Schema output
- Same canonical Pydantic schema as Solution 1
- Groq API key only; no OpenAI API key
- Model can process invoice text and, for a vision implementation, invoice page images

## Groq setup

Create a Groq API key and put it in `.env`:

```env
GROQ_API_KEY=your_key_here
GROQ_MODEL=qwen/qwen3.8-27b
```

Install:

```bash
pip install -r requirements.txt
```

Run:

```bash
python main.py --mode deterministic --input data/raw/invoice.pdf
python main.py --mode llm --input data/raw/invoice.pdf
python main.py --mode both --input data/raw/invoice.pdf
```

Groq supports structured outputs using JSON Schema. Strict mode requires all schema fields to be required and objects to use `additionalProperties: false`, so the final assessment schema should be designed accordingly.

## Assessment rule

The final schema must contain **ONLY the highlighted/required fields** from the assessment.

First review all invoice templates, identify layout/label variations, then finalize the canonical schema. Both pipelines must produce that exact same schema so their results can be compared field-by-field.

## Architecture

Invoice
→ PDF text extraction / OCR
→ Deterministic pipeline OR Groq pipeline
→ Canonical Pydantic schema
→ JSON
→ Field-by-field comparison
