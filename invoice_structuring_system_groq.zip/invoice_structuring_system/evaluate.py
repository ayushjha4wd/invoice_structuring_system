def main():
    print("Evaluation scaffold ready. Add verified ground-truth JSON files.")

if __name__ == "__main__":
    main()
