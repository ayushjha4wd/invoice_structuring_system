import fitz

def extract_text_and_blocks(pdf_path: str):
    doc = fitz.open(pdf_path)
    text_parts, blocks = [], []
    for page_no, page in enumerate(doc):
        text_parts.append(page.get_text())
        for block in page.get_text("blocks"):
            blocks.append({
                "page": page_no, "x0": block[0], "y0": block[1],
                "x1": block[2], "y1": block[3], "text": block[4],
            })
    doc.close()
    return "\n".join(text_parts).strip(), blocks
