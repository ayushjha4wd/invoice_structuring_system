from pdf2image import convert_from_path
import pytesseract
from config.settings import settings

def ocr_pdf(pdf_path: str) -> str:
    if settings.tesseract_cmd:
        pytesseract.pytesseract.tesseract_cmd = settings.tesseract_cmd
    images = convert_from_path(str(pdf_path), dpi=settings.ocr_dpi)
    return "\n".join(pytesseract.image_to_string(img) for img in images).strip()
