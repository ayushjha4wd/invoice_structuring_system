def compare_dicts(a: dict, b: dict, prefix=""):
    differences = []
    for key in set(a) | set(b):
        path = f"{prefix}.{key}" if prefix else key
        av, bv = a.get(key), b.get(key)
        if isinstance(av, dict) and isinstance(bv, dict):
            differences.extend(compare_dicts(av, bv, path))
        elif av != bv:
            differences.append({"field": path, "deterministic": av, "llm": bv, "match": False})
    return differences
