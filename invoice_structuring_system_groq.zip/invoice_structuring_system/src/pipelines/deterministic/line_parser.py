def parse_line_items(text: str) -> list[dict]:
    # Implement highlighted item fields after dataset analysis.
    return []
