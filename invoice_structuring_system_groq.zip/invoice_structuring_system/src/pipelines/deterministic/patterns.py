# Populate these aliases from ALL invoice templates after dataset analysis.
FIELD_ALIASES = {
    "buyer": ["buyer", "bill to", "billed to", "buyer to party", "details of recipient"],
    "consignee": ["consignee", "ship to", "shipped to party", "ship to party"],
    "invoice_number": ["invoice no", "invoice number", "invoice #"],
}
