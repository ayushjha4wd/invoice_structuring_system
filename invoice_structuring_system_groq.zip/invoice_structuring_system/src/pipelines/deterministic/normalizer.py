import re

def clean_text(value):
    return re.sub(r"\s+", " ", value).strip() if value else None

def clean_number(value):
    if value is None:
        return None
    cleaned = re.sub(r"[^0-9.\-]", "", value.replace(",", ""))
    try:
        return float(cleaned)
    except ValueError:
        return None
