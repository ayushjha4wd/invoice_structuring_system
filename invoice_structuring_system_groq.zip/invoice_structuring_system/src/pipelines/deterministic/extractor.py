import re
from src.pipelines.base import BaseInvoiceExtractor
from src.preprocessors.pdf_loader import extract_text_and_blocks
from src.preprocessors.ocr_engine import ocr_pdf
from src.schemas.invoice_schema import InvoiceData

INVOICE_NUMBER_RE = re.compile(
    r"(?:invoice\s*(?:no|number|#)|bill\s*(?:no|number))\s*[:#-]?\s*([A-Za-z0-9./_-]+)", re.I
)

class DeterministicExtractor(BaseInvoiceExtractor):
    def extract(self, input_path: str) -> InvoiceData:
        text, _ = extract_text_and_blocks(input_path)
        if len(text.strip()) < 30:
            text = ocr_pdf(input_path)
        invoice_number = None
        match = INVOICE_NUMBER_RE.search(text)
        if match:
            invoice_number = match.group(1)
        return InvoiceData(
            seller={"name": None},
            buyer={"name": None},
            consignee={"name": None},
            invoice={"number": invoice_number},
        )
