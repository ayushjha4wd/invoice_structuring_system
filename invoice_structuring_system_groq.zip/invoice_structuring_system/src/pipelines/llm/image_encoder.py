# Reserved for the vision path.
# Groq vision-capable models can accept image inputs directly.
# The current implementation sends extracted/OCR text to keep the pipeline simple.
