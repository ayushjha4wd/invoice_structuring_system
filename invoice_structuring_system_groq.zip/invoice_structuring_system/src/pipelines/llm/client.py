import json
from groq import Groq
from config.settings import settings

class LLMClient:
    """Groq client for the LLM extraction pipeline."""

    def __init__(self):
        if not settings.groq_api_key:
            raise RuntimeError("GROQ_API_KEY is not configured")
        self.client = Groq(api_key=settings.groq_api_key)
        self.model = settings.groq_model

    def extract(self, prompt: str, document_text: str, schema: dict):
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": prompt},
                {
                    "role": "user",
                    "content": f"Extract the required fields from this invoice text:\n\n{document_text}"
                },
            ],
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "invoice_extraction",
                    "strict": True,
                    "schema": schema,
                },
            },
        )
        return response.choices[0].message.content
