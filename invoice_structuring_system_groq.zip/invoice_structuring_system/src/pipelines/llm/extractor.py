import json

from src.pipelines.base import BaseInvoiceExtractor
from src.preprocessors.pdf_loader import extract_text_and_blocks
from src.preprocessors.ocr_engine import ocr_pdf
from src.pipelines.llm.client import LLMClient
from src.pipelines.llm.prompts import SYSTEM_PROMPT
from src.schemas.invoice_schema import InvoiceData

class LLMExtractor(BaseInvoiceExtractor):
    def extract(self, input_path: str) -> InvoiceData:
        text, _ = extract_text_and_blocks(input_path)

        if len(text.strip()) < 30:
            text = ocr_pdf(input_path)

        schema = InvoiceData.model_json_schema()
        raw = LLMClient().extract(SYSTEM_PROMPT, text, schema)
        return InvoiceData.model_validate(json.loads(raw))
