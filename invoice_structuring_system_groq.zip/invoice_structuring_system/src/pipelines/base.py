from abc import ABC, abstractmethod
from src.schemas.invoice_schema import InvoiceData

class BaseInvoiceExtractor(ABC):
    @abstractmethod
    def extract(self, input_path: str) -> InvoiceData:
        raise NotImplementedError
