from pydantic import BaseModel, ConfigDict

class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

# IMPORTANT: Replace/extend these fields ONLY with the highlighted fields
# required by the assessment after reviewing the complete invoice dataset.

class Party(StrictModel):
    name: str | None = None

class InvoiceDetails(StrictModel):
    number: str | None = None

class InvoiceData(StrictModel):
    seller: Party | None = None
    buyer: Party | None = None
    consignee: Party | None = None
    invoice: InvoiceDetails | None = None
